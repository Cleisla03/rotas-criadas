package com.example.rotas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(RotasApplication.class, args);
	}

}
