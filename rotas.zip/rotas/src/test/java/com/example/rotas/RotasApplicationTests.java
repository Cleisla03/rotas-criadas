package com.example.rotas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RotasApplicationTests {

	@Test
	void contextLoads() {
	}

}
